@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Dreamy Xmas Hand Joint Tracking Server
echo ============================================================
echo Dreamy Xmas Hand Joint Tracking V2 - Local Server
echo ============================================================
echo.
echo Starting. Keep this window open while using the page.
echo The browser should open automatically. If it does not, copy the address shown below.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
    py -3 start_server.py
    goto end
)
where python >nul 2>nul
if %errorlevel%==0 (
    python start_server.py
    goto end
)
echo Python was not detected.
echo Please install Python 3, then run this file again.
echo You may also run: python start_server.py
:end
echo.
pause
