Set-Location -Path $PSScriptRoot
$py = Get-Command py -ErrorAction SilentlyContinue
if ($py) {
  py -3 start_server.py
  exit
}
$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) {
  python start_server.py
  exit
}
Write-Host "Python was not detected. Please install Python 3, then run: python start_server.py"
Read-Host "Press Enter to exit"
